# from flask import Flask, request, render_template, redirect
# import mysql.connector

# app = Flask(__name__)

# # Database connection details
# DB_HOST = "db"
# DB_USER = "root"
# DB_PASSWORD = "skickar443"
# DB_NAME = "users"

# def get_db_connection():
#     return mysql.connector.connect(
#         host=DB_HOST,
#         user=DB_USER,
#         password=DB_PASSWORD,
#         database=DB_NAME
#     )

# @app.route('/')
# def home():
#     return render_template('index.html')

# @app.route('/register', methods=['POST'])
# def register():
#     username = request.form['username']
#     password = request.form['password']
#     conn = get_db_connection()
#     cursor = conn.cursor()
#     cursor.execute("INSERT INTO users (username, password) VALUES (%s, %s)", (username, password))
#     conn.commit()
#     cursor.close()
#     conn.close()
#     return redirect('/')

# @app.route('/login', methods=['POST'])
# def login():
#     username = request.form['username']
#     password = request.form['password']
#     conn = get_db_connection()
#     cursor = conn.cursor()
#     cursor.execute("SELECT * FROM users WHERE username = %s AND password = %s", (username, password))
#     user = cursor.fetchone()
#     cursor.close()
#     conn.close()
#     if user:
#         return "Login Successful!"
#     return "Invalid Credentials!"

# if __name__ == "__main__":
#     app.run(host='0.0.0.0', port=5000)

from flask import Flask, request, render_template, redirect, flash, url_for
import mysql.connector

app = Flask(__name__)
app.secret_key = 'your_secret_key'  # Required for flashing messages

DB_HOST = "db"
DB_USER = "root"
DB_PASSWORD = "skickar443"
DB_NAME = "users"

def get_db_connection():
    return mysql.connector.connect(
        host=DB_HOST,
        user=DB_USER,
        password=DB_PASSWORD,
        database=DB_NAME
    )

@app.route('/')
def home():
    return render_template('index.html', message=None)

@app.route('/register', methods=['POST'])
def register():
    username = request.form['username']
    password = request.form['password']
    conn = get_db_connection()
    cursor = conn.cursor()

    try:
        cursor.execute("INSERT INTO users (username, password) VALUES (%s, %s)", (username, password))
        conn.commit()
        cursor.close()
        conn.close()
        return render_template('index.html', message="Registration successful!", message_class="success")
    except mysql.connector.Error as err:
        return render_template('index.html', message="Error during registration. Please try again.", message_class="error")

@app.route('/login', methods=['POST'])
def login():
    username = request.form['username']
    password = request.form['password']
    conn = get_db_connection()
    cursor = conn.cursor()
    
    cursor.execute("SELECT * FROM users WHERE username = %s AND password = %s", (username, password))
    user = cursor.fetchone()
    cursor.close()
    conn.close()

    if user:
        return render_template('index.html', message="Login successful! Welcome back!", message_class="success")
    else:
        return render_template('index.html', message="Invalid username or password. Please try again.", message_class="error")

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
